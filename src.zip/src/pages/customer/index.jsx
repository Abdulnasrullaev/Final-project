import React from "react";
import {Customers} from "./style";

function Customer() {
    return(
        <>
           <Customers>
               this is customer
           </Customers>
        </>
    )

}
export default Customer