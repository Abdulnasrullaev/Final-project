import React from "react";
import {Messages} from "./style";


function Message() {
    return(
        <>
        <Messages>
            this is message
        </Messages>
        </>
    )
}
export default Message