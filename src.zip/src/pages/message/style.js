import styled from "styled-components";

export const Messages = styled.div`
  width: 83.9%;
  position: absolute;
margin: 60px 220px;
  padding: 2px 0;
  background-color: #FAFAFA;
`;