import React from "react";
import { Link } from "react-router-dom";
import { Navheader } from "./style";

function NavHeader() {
  return (
    <>
      <Navheader>
        <p className="logo">Dashboard</p>
        <ul>
          <li>
            <Link to="/dashboard">
              <img
                src="https://img.icons8.com/material-outlined/24/000000/medium-icons.png"
                alt=""
              />{" "}
              <span>Dashboard</span>{" "}
            </Link>
          </li>
          <li>
            <Link to="/product">
              <img
                src="https://img.icons8.com/ios-filled/50/000000/shopping-cart.png"
                alt=""
              />{" "}
              <span> Products</span>
            </Link>
          </li>
          <li>
            <Link to="/customer">
              <img
                src="https://img.icons8.com/ios-filled/64/000000/user-group-man-man.png"
                alt=""
              />
              <span>Customer</span>
            </Link>
          </li>
          <li>
            <Link to="/message">
              <img
                src="https://img.icons8.com/external-gradak-royyan-wijaya/24/000000/external-communication-gradak-communikatok-solidarity-gradak-royyan-wijaya-6.png"
                alt=""
              />
              <span>Message</span>
            </Link>{" "}
          </li>
          <li>
            <a href="#">
              <img
                src="https://img.icons8.com/glyph-neue/128/000000/settings.png"
                alt=""
              />{" "}
              <span> Settings</span>
            </a>
          </li>
        </ul>
      </Navheader>
    </>
  );
}

export default NavHeader;
