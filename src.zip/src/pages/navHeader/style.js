import styled from "styled-components";

export const Navheader = styled.div`
  width: 16%;
  background-color: springgreen;
  position: fixed;
  height: 100%;
  z-index: 999;
  text-align: center;
  ul {
    margin: 30px -30px auto;
    align-items: center;
    li {
      align-items: center;
      list-style: none;
      width: 200px;
      margin: 10px 0;
      padding: 4px 10px;
      a {
        text-align: center;
        padding: 8px 10px;
        border-radius: 10px;
        width: 160px;
        display: flex;
        text-decoration: none;

        span {
          position: relative;
          top: 3.4px;
          color: black;
          right: 20px;
        }
        img {
          width: 30px;
          position: relative;
          margin: -2px 50px 0px 0px;
          top: 2px;
          right: 5px;
        }
      }
    }
  }
  li:hover{
    background-color: lightskyblue;
    border-radius: 10px;
    width: 180px;
  }

  li:focus-within {
    background-color: #edf6ff;
    color: #45a9ff;
    width: fit-content;
    border-radius: 10px;
    color: coral;
    img {
      filter: invert(57%) sepia(28%) saturate(4643%) hue-rotate(189deg)
        brightness(105%) contrast(101%);
    }
    span{
      color: #45A5FF;
    }
  }
`;
