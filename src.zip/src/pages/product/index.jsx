import React, { useState, useEffect } from "react";
import { Products } from "./style";
import axios from "axios";
import ImgModal from "./productModal";

function Product() {
  const [show, setShowModal] = useState(false);
  const [data, setData] = useState();


 const getData=()=>{
  axios
    .get(
      "https://virtserver.swaggerhub.com/maraimtuxtasunov/store_api_docs/1.0.0/api/v1/product"
    )
    .then((res) => {
      setData(res.data);
      console.log(res.data);
    })
    .catch((err)=>{
      console.log("error", err);
    })
  }

  useEffect(() => {
    getData()
  }, [])
  return (
    <>
      <Products>
        <div className="btn-group">
          <button>Update</button>
          <button>Delete</button>
          <p className="title">Products</p>
        </div>
        <div className="cart-img">
          <a href="#">
            {" "}
            <img src="https://img.icons8.com/ios-glyphs/30/000000/shopping-cart--v1.png" />
          </a>
        </div>

        <ul className="navs">
          <li>
            <a href="#">All Product</a>
          </li>
          <li>
            <a href="#">Completed</a>
          </li>
          <li>
            <a href="#">Panding</a>
          </li>
          <li>
            <a href="#">Cancel</a>
          </li>
        </ul>
        <table className="table">
          <tr>
            <th style={{ width: "fit-content" }}>#</th>
            <th>Poduct ID</th>
            <th>Product Name</th>
            <th>Address</th>
            <th>Data</th>
            <th>Price</th>
            <th>Status</th>
          </tr>
          <div className="hr"></div>
          <tr>
            <td style={{ width: "fit-content" }}>1</td>
            <td>#836189</td>
            <td>
              <img
                src="https://cdn.pixabay.com/photo/2020/07/15/18/29/sneakers-5408659_960_720.png"
                alt=""
              />{" "}
              <span> Nike Air Max</span>
            </td>
            <td>361 Address Forest Drive</td>
            <td>01/03/2021</td>
            <td>$329.00</td>
            <td>
              {" "}
              <a href="#">
                <img src="https://img.icons8.com/ios-glyphs/30/000000/shopping-cart--v1.png" />
              </a>
            </td>
          </tr>
          <tr>
            <td style={{ width: "fit-content" }}>1</td>
            <td>#836189</td>
            <td>
              <img
                src="https://cdn.pixabay.com/photo/2020/07/15/18/29/sneakers-5408659_960_720.png"
                alt=""
              />{" "}
              <span> Nike Air Max</span>
            </td>
            <td>361 Address Forest Drive</td>
            <td>01/03/2021</td>
            <td>$329.00</td>
            <td>
              {" "}
              <a href="#">
                <img src="https://img.icons8.com/ios-glyphs/30/000000/shopping-cart--v1.png" />
              </a>
            </td>
          </tr>
        </table>
      </Products>
    </>
  );
}
export default Product;
