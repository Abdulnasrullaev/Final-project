import React from 'react'
import styled from 'styled-components'



function ImgModal() {
    return (
        <div>
            <input type="text" placeholder='Product Name' />
            <textarea name="desrciption" placeholder='Write something else' cols="30" rows="10"></textarea>
        </div>
    )
}

export default ImgModal
